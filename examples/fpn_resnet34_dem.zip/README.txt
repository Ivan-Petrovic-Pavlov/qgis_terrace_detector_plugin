Model bundle for the QGIS plugin Detekcia teras / Terrace detection.
Balik modelu pre QGIS plugin Detekcia teras / Terrace detection.
Select this ZIP in the inference tool. The input raster is selected from QGIS.
Vyberte tento ZIP v nastroji inferencie. Vstupny raster vyberiete z QGIS.
PyTorch and model libraries must be available in the QGIS Python.
PyTorch a kniznica modelu musia byt dostupne v Pythone QGIS.
